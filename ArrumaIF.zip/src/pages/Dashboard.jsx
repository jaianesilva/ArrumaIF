import React from 'react'
import {
  Box, Typography, Grid, Card, CardContent,
  Chip, LinearProgress
} from '@mui/material'
import BuildIcon from '@mui/icons-material/Build'
import FolderOpenIcon from '@mui/icons-material/FolderOpen'
import SettingsIcon from '@mui/icons-material/Settings'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'

import { chamados, locais, categorias } from '../data/database.js'

function Dashboard() {

  // Calcula quantos chamados existem em cada status
  const total = chamados.length
  const abertos = chamados.filter(c => c.status === 'aberto').length
  const andamento = chamados.filter(c => c.status === 'em_andamento').length
  const resolvidos = chamados.filter(c => c.status === 'resolvido').length

  const porCategoria = categorias.map(cat => ({
    ...cat,
    total: chamados.filter(c => c.categoria_id === cat.id).length
  }))

  const maiorTotal = Math.max(...porCategoria.map(c => c.total))

  function getNomeLocal(id) {
    const local = locais.find(l => l.id === id)
    return local ? local.nome : '—'
  }

  const recentes = chamados.filter(c => c.status !== 'resolvido').slice(0, 4)

  const cards = [
    { label: 'Total de Chamados', valor: total,      icon: <BuildIcon />,        cor: '#2d8c3e', bg: '#edf7ef' },
    { label: 'Abertos',           valor: abertos,    icon: <FolderOpenIcon />,   cor: '#1565c0', bg: '#e3f2fd' },
    { label: 'Em Andamento',      valor: andamento,  icon: <SettingsIcon />,     cor: '#e65100', bg: '#fff3e0' },
    { label: 'Resolvidos',        valor: resolvidos, icon: <CheckCircleIcon />,  cor: '#2e7d32', bg: '#e8f5e9' },
  ]

  const corPrioridade = { urgente: 'error', alta: 'warning', media: 'default', baixa: 'success' }

  return (
    <Box>

      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">📊 Dashboard</Typography>
        <Typography color="text.secondary" mt={0.5}>
          Visão geral dos chamados de manutenção do campus
        </Typography>
      </Box>

      <Grid container spacing={2} mb={3}>
        {cards.map((card, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card elevation={0} sx={{ border: '1px solid #e0e0e0' }}>
              <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ background: card.bg, color: card.cor, borderRadius: 2, p: 1.2, display: 'flex' }}>
                  {card.icon}
                </Box>
                <Box>
                  <Typography variant="h4" fontWeight="bold">{card.valor}</Typography>
                  <Typography variant="caption" color="text.secondary">{card.label}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>

        <Grid item xs={12} md={6}>
          <Card elevation={0} sx={{ border: '1px solid #e0e0e0', height: '100%' }}>
            <CardContent>
              <Typography fontWeight="bold" mb={2}>Por Categoria</Typography>
              {porCategoria.map(cat => (
                <Box key={cat.id} mb={1.5}>
                  <Box display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2">{cat.icone} {cat.nome}</Typography>
                    <Typography variant="body2" fontWeight="bold">{cat.total}</Typography>
                  </Box>
                  <LinearProgress
                    variant="determinate"
                    value={maiorTotal > 0 ? (cat.total / maiorTotal) * 100 : 0}
                    sx={{
                      borderRadius: 99,
                      height: 6,
                      backgroundColor: '#e0e0e0',
                      '& .MuiLinearProgress-bar': { backgroundColor: '#2d8c3e' }
                    }}
                  />
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card elevation={0} sx={{ border: '1px solid #e0e0e0', height: '100%' }}>
            <CardContent>
              <Typography fontWeight="bold" mb={2}>Chamados Recentes</Typography>
              {recentes.map(c => (
                <Box
                  key={c.id}
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  py={1.2}
                  sx={{ borderBottom: '1px solid #f0f0f0' }}
                >
                  <Box>
                    <Typography variant="body2" fontWeight="bold">{c.titulo}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      📍 {getNomeLocal(c.local_id)}
                    </Typography>
                  </Box>
                  <Chip label={c.prioridade} size="small" color={corPrioridade[c.prioridade] || 'default'} />
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

      </Grid>
    </Box>
  )
}

export default Dashboard
