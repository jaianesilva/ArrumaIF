export const usuarios = [
  { id: 1, nome: 'Ana Julia Vieira', prontuario: 'BP303030', senha: '123456', tipo: 'aluno', turma: 'ADS3A' },
  { id: 2, nome: 'Jaiane Silva', prontuario: 'BP3030145', senha: '123456', tipo: 'aluno', turma: 'ADS3A' },
  { id: 3, nome: 'Ana Paula Giancoli', prontuario: 'BP0001234', senha: '123456', tipo: 'professor', turma: null },
  { id: 4, nome: 'Clayton Eduardo dos Santos', prontuario: 'BP2029871', senha: '123456', tipo: 'aluno', turma: 'ADS2B' },
  { id: 5, nome: 'Jonnas Oliveira', prontuario: 'BP0005678', senha: '123456', tipo: 'servidor', turma: null },
]

export const locais = [
  { id: 1, nome: 'Laboratório de Informática sala A401', bloco: 'A', andar: '4º Andar' },
  { id: 2, nome: 'Sala de Aula B514', bloco: 'B', andar: '5º Andar' },
  { id: 3, nome: 'Corredor Principal', bloco: 'A', andar: 'Térreo' },
  { id: 4, nome: 'Laboratório de Informática sala A408', bloco: 'A', andar: '4º Andar' },
  { id: 5, nome: 'Banheiro Feminino', bloco: 'A', andar: 'Térreo' },
]

export const categorias = [
  { id: 1, nome: 'Informática', icone: '💻', descricao: 'Computadores, monitores e periféricos' },
  { id: 2, nome: 'Audiovisual', icone: '📽️', descricao: 'Projetores e equipamentos de apresentação' },
  { id: 3, nome: 'Climatização', icone: '🌀', descricao: 'Ventiladores e ar-condicionado' },
  { id: 4, nome: 'Hidráulica', icone: '💧', descricao: 'Torneiras, vasos e vazamentos' },
  { id: 5, nome: 'Mobiliário', icone: '🪑', descricao: 'Cadeiras, mesas e armários' },
]

export const chamados = [
  {
    id: 1,
    titulo: 'Projetor Quebrado',
    descricao: 'O projetor não liga de forma consistente e a imagem fica com falhas, impactando as aulas de apresentação.',
    usuario_id: 1,
    local_id: 1,
    categoria_id: 2,
    status: 'em_andamento',
    prioridade: 'alta',
  },
  {
    id: 2,
    titulo: 'Computador com Defeito',
    descricao: 'O computador não inicializa o sistema operacional.',
    usuario_id: 2,
    local_id: 5,
    categoria_id: 1,
    status: 'aberto',
    prioridade: 'media',
  },
  {
    id: 3,
    titulo: 'Cadeiras Quebradas - Sala B401',
    descricao: 'Três cadeiras com pernas quebradas, oferecendo risco aos alunos.',
    usuario_id: 3,
    local_id: 2,
    categoria_id: 5,
    status: 'resolvido',
    prioridade: 'alta',
  },
  {
    id: 4,
    titulo: 'Lâmpada Queimada',
    descricao: 'Lâmpadas do corredor principal queimadas, dificultando a circulação.',
    usuario_id: 4,
    local_id: 3,
    categoria_id: 1,
    status: 'aberto',
    prioridade: 'baixa',
  },
  {
    id: 5,
    titulo: 'Computador Travando',
    descricao: 'Computador da posição 5 trava constantemente durante as aulas práticas.',
    usuario_id: 1,
    local_id: 4,
    categoria_id: 1,
    status: 'aberto',
    prioridade: 'media',
  },
  {
    id: 6,
    titulo: 'Ventilador Parado',
    descricao: 'Ventilador não liga e a sala fica muito quente durante as aulas da tarde.',
    usuario_id: 4,
    local_id: 2,
    categoria_id: 3,
    status: 'em_andamento',
    prioridade: 'media',
  },
]
