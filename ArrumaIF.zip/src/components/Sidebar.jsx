import React from 'react'
import {
  Drawer, List, ListItemButton, ListItemIcon,
  ListItemText, Typography, Box, Divider
} from '@mui/material'
import DashboardIcon from '@mui/icons-material/Dashboard'
import BuildIcon from '@mui/icons-material/Build'
import ViewKanbanIcon from '@mui/icons-material/ViewKanban'
import LocationOnIcon from '@mui/icons-material/LocationOn'
import CategoryIcon from '@mui/icons-material/Category'
import PeopleIcon from '@mui/icons-material/People'
import LogoutIcon from '@mui/icons-material/Logout'
import logo from '../assets/arrumaif-logo.png'

// Lista dos itens do menu lateral
const navItems = [
  { id: 'dashboard',  label: 'Dashboard',   icon: <DashboardIcon /> },
  { id: 'chamados',   label: 'Chamados',    icon: <BuildIcon /> },
  { id: 'andamento',  label: 'Andamento',   icon: <ViewKanbanIcon /> },
  { id: 'locais',     label: 'Locais',      icon: <LocationOnIcon /> },
  { id: 'categorias', label: 'Categorias',  icon: <CategoryIcon /> },
  { id: 'usuarios',   label: 'Usuários',    icon: <PeopleIcon /> },
]

function Sidebar({ paginaAtiva, onNavegar, usuarioLogado, onSair }) {

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 220,
        '& .MuiDrawer-paper': {
          width: 220,
          background: '#2d8c3e',
          color: 'white',
          border: 'none',
        }
      }}
    >

      <Box sx={{ p: 2.5, pb: 2, display: 'flex', justifyContent: 'center' }}>
        <img src={logo} alt="ArrumaIF" style={{ width: '85%', height: 'auto' }} />
      </Box>

      <Divider sx={{ borderColor: 'rgba(255,255,255,0.15)' }} />

      <List sx={{ px: 1, pt: 1 }}>
        {navItems.map(item => {
          const ativo = paginaAtiva === item.id
          return (
            <ListItemButton
              key={item.id}
              onClick={() => onNavegar(item.id)}
              sx={{
                borderRadius: 2,
                mb: 0.5,
                color: ativo ? '#2d8c3e' : 'rgba(255,255,255,0.75)',
                background: ativo ? 'white' : 'transparent',
                '&:hover': {
                  background: ativo ? 'white' : 'rgba(255,255,255,0.12)',
                  color: ativo ? '#2d8c3e' : 'white',
                }
              }}
            >
              <ListItemIcon sx={{ color: 'inherit', minWidth: 36 }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{
                  fontSize: 14,
                  fontWeight: ativo ? 700 : 400
                }}
              />
            </ListItemButton>
          )
        })}
      </List>

      <Box sx={{ mt: 'auto', p: 2 }}>
        <Divider sx={{ borderColor: 'rgba(255,255,255,0.15)', mb: 1.5 }} />

        {usuarioLogado && (
          <Typography fontSize={12} color="white" mb={1}>
          </Typography>
        )}

        <ListItemButton
          onClick={onSair}
          sx={{
            borderRadius: 2,
            color: 'rgba(255,255,255,0.75)',
            '&:hover': { background: 'rgba(255,255,255,0.12)', color: 'white' }
          }}
        >
          <ListItemIcon sx={{ color: 'inherit', minWidth: 36 }}>
            <LogoutIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Sair" primaryTypographyProps={{ fontSize: 13 }} />
        </ListItemButton>

        <Typography fontSize={11} color="rgba(255,255,255,0.35)" mt={1.5}>
          IFSP Bragança Paulista · ADS · 2026
        </Typography>
      </Box>
    </Drawer>
  )
}

export default Sidebar
