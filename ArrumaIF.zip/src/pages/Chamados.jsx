import React, { useState } from 'react'
import {
  Box, Typography, Button, TextField, Select, MenuItem,
  FormControl, InputLabel, Card, Table, TableHead, TableBody,
  TableRow, TableCell, Chip, IconButton, Dialog, DialogTitle,
  DialogContent, DialogActions, Grid
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'

import { chamados as dadosChamados, usuarios, locais, categorias } from '../data/database.js'

function Chamados() {

  const [chamados, setChamados] = useState(dadosChamados)
  const [busca, setBusca] = useState('')
  const [filtroStatus, setFiltroStatus] = useState('')
  const [abrirModal, setAbrirModal] = useState(false)
  const [editandoId, setEditandoId] = useState(null)

  const [form, setForm] = useState({
    titulo: '',
    descricao: '',
    usuario_id: '',
    local_id: '',
    categoria_id: '',
    status: 'aberto',
    prioridade: 'media'
  })

  function getNome(lista, id) {
    const item = lista.find(elemento => elemento.id === Number(id))
    return item ? item.nome : '—'
  }

  const lista = chamados.filter(chamado => {
    const buscaTitulo = chamado.titulo.toLowerCase().includes(busca.toLowerCase())
    const buscaStatus = filtroStatus === '' || chamado.status === filtroStatus
    return buscaTitulo && buscaStatus
  })

  function abrirNovo() {
    setForm({
      titulo: '', descricao: '', usuario_id: '', local_id: '',
      categoria_id: '', status: 'aberto', prioridade: 'media'
    })
    setEditandoId(null)
    setAbrirModal(true)
  }

  function abrirEdicao(chamado) {
    setForm({
      titulo: chamado.titulo,
      descricao: chamado.descricao,
      usuario_id: chamado.usuario_id,
      local_id: chamado.local_id,
      categoria_id: chamado.categoria_id,
      status: chamado.status,
      prioridade: chamado.prioridade
    })
    setEditandoId(chamado.id)
    setAbrirModal(true)
  }

  function salvarChamado() {
    if (!form.titulo || !form.usuario_id || !form.local_id || !form.categoria_id) {
      alert('Preencha os campos obrigatórios!')
      return
    }

    if (editandoId) {
      const atualizados = chamados.map(c =>
        c.id === editandoId
          ? { ...c, ...form, usuario_id: Number(form.usuario_id), local_id: Number(form.local_id), categoria_id: Number(form.categoria_id) }
          : c
      )
      setChamados(atualizados)
    } else {
      const novoChamado = {
        id: chamados.length + 1,
        ...form,
        usuario_id: Number(form.usuario_id),
        local_id: Number(form.local_id),
        categoria_id: Number(form.categoria_id)
      }
      setChamados([...chamados, novoChamado])
    }

    setAbrirModal(false)
  }

  function excluir(id) {
    if (window.confirm('Excluir este chamado?')) {
      setChamados(chamados.filter(c => c.id !== id))
    }
  }

  const corStatus = { aberto: 'warning', em_andamento: 'info', resolvido: 'success' }
  const corPrioridade = { urgente: 'error', alta: 'warning', media: 'default', baixa: 'success' }

  return (
    <Box>

      <Typography variant="h5" fontWeight="bold" mb={1}>
        🔧 Chamados
      </Typography>

      <Typography color="text.secondary" mb={3}>
        Gerenciamento dos chamados de manutenção
      </Typography>

      <Box display="flex" gap={2} mb={3} flexWrap="wrap">

        <TextField
          size="small"
          label="Buscar"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />

        <FormControl size="small" sx={{ minWidth: 160 }}>
          <InputLabel>Status</InputLabel>
          <Select
            value={filtroStatus}
            label="Status"
            onChange={(e) => setFiltroStatus(e.target.value)}
          >
            <MenuItem value="">Todos</MenuItem>
            <MenuItem value="aberto">Aberto</MenuItem>
            <MenuItem value="em_andamento">Em andamento</MenuItem>
            <MenuItem value="resolvido">Resolvido</MenuItem>
          </Select>
        </FormControl>

        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={abrirNovo}
        >
          Novo Chamado
        </Button>

      </Box>

      <Card>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Título</TableCell>
              <TableCell>Solicitante</TableCell>
              <TableCell>Local</TableCell>
              <TableCell>Prioridade</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {lista.map(chamado => (
              <TableRow key={chamado.id}>
                <TableCell>{chamado.id}</TableCell>
                <TableCell>{chamado.titulo}</TableCell>
                <TableCell>{getNome(usuarios, chamado.usuario_id)}</TableCell>
                <TableCell>{getNome(locais, chamado.local_id)}</TableCell>
                <TableCell>
                  <Chip label={chamado.prioridade} size="small" color={corPrioridade[chamado.prioridade]} />
                </TableCell>
                <TableCell>
                  <Chip
                    label={chamado.status === 'em_andamento' ? 'Em andamento' : chamado.status}
                    size="small"
                    color={corStatus[chamado.status]}
                  />
                </TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => abrirEdicao(chamado)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => excluir(chamado.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={abrirModal} onClose={() => setAbrirModal(false)}>
        <DialogTitle>{editandoId ? 'Editar Chamado' : 'Novo Chamado'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} mt={1}>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                value={form.titulo}
                onChange={(e) => setForm({ ...form, titulo: e.target.value })}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Descrição"
                value={form.descricao}
                onChange={(e) => setForm({ ...form, descricao: e.target.value })}
              />
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Solicitante</InputLabel>
                <Select
                  value={form.usuario_id}
                  label="Solicitante"
                  onChange={(e) => setForm({ ...form, usuario_id: e.target.value })}
                >
                  {usuarios.map(u => (
                    <MenuItem key={u.id} value={u.id}>{u.nome}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Local</InputLabel>
                <Select
                  value={form.local_id}
                  label="Local"
                  onChange={(e) => setForm({ ...form, local_id: e.target.value })}
                >
                  {locais.map(l => (
                    <MenuItem key={l.id} value={l.id}>{l.nome}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Categoria</InputLabel>
                <Select
                  value={form.categoria_id}
                  label="Categoria"
                  onChange={(e) => setForm({ ...form, categoria_id: e.target.value })}
                >
                  {categorias.map(c => (
                    <MenuItem key={c.id} value={c.id}>{c.icone} {c.nome}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={6}>
              <FormControl fullWidth>
                <InputLabel>Prioridade</InputLabel>
                <Select
                  value={form.prioridade}
                  label="Prioridade"
                  onChange={(e) => setForm({ ...form, prioridade: e.target.value })}
                >
                  <MenuItem value="baixa">Baixa</MenuItem>
                  <MenuItem value="media">Média</MenuItem>
                  <MenuItem value="alta">Alta</MenuItem>
                  <MenuItem value="urgente">Urgente</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={6}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={form.status}
                  label="Status"
                  onChange={(e) => setForm({ ...form, status: e.target.value })}
                >
                  <MenuItem value="aberto">Aberto</MenuItem>
                  <MenuItem value="em_andamento">Em andamento</MenuItem>
                  <MenuItem value="resolvido">Resolvido</MenuItem>
                </Select>
              </FormControl>
            </Grid>

          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAbrirModal(false)}>Cancelar</Button>
          <Button variant="contained" onClick={salvarChamado}>Salvar</Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default Chamados
