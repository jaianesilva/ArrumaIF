import React, { useState } from 'react'
import {
  Box, Typography, Button, Card, CardContent, Chip,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Grid, IconButton
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'

import { categorias as dadosCategorias, chamados } from '../data/database.js'

function Categorias() {

  const [categorias, setCategorias] = useState(dadosCategorias)
  const [abrirModal, setAbrirModal] = useState(false)
  const [editandoId, setEditandoId] = useState(null)
  const [form, setForm] = useState({ nome: '', icone: '🔧', descricao: '' })

  function contarChamados(idCategoria) {
    return chamados.filter(
      chamado => chamado.categoria_id === idCategoria
    ).length
  }

  function abrirNovo() {
    setForm({ nome: '', icone: '🔧', descricao: '' })
    setEditandoId(null)
    setAbrirModal(true)
  }

  function abrirEdicao(categoria) {
    setForm({ nome: categoria.nome, icone: categoria.icone, descricao: categoria.descricao })
    setEditandoId(categoria.id)
    setAbrirModal(true)
  }

  function salvarCategoria() {
    if (form.nome === '') {
      alert('Digite o nome da categoria')
      return
    }

    if (editandoId) {
      const atualizados = categorias.map(c =>
        c.id === editandoId ? { ...c, ...form } : c
      )
      setCategorias(atualizados)
    } else {
      const categoria = { id: categorias.length + 1, ...form }
      setCategorias([...categorias, categoria])
    }

    setAbrirModal(false)
  }

  function excluir(id) {
    setCategorias(categorias.filter(c => c.id !== id))
  }

  return (
    <Box>

      <Typography variant="h5" fontWeight="bold" mb={1}>
        🏷️ Categorias
      </Typography>

      <Typography color="text.secondary" mb={3}>
        Categorias dos chamados de manutenção
      </Typography>

      <Button
        variant="contained"
        startIcon={<AddIcon />}
        onClick={abrirNovo}
        sx={{ mb: 3 }}
      >
        Nova Categoria
      </Button>

      <Grid container spacing={2}>
        {categorias.map(categoria => (
          <Grid item xs={12} sm={6} md={4} key={categoria.id}>
            <Card>
              <CardContent>
                <Typography fontSize={35}>{categoria.icone}</Typography>
                <Typography fontWeight="bold" mt={1}>{categoria.nome}</Typography>
                <Typography variant="body2" color="text.secondary" mt={1} sx={{ minHeight: 40 }}>
                  {categoria.descricao}
                </Typography>
                <Box display="flex" justifyContent="space-between" alignItems="center" mt={2}>
                  <Chip label={contarChamados(categoria.id) + ' chamado(s)'} />
                  <Box>
                    <IconButton size="small" color="primary" onClick={() => abrirEdicao(categoria)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" color="error" onClick={() => excluir(categoria.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={abrirModal} onClose={() => setAbrirModal(false)}>
        <DialogTitle>{editandoId ? 'Editar Categoria' : 'Nova Categoria'}</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth label="Ícone" margin="normal"
            value={form.icone}
            onChange={(e) => setForm({ ...form, icone: e.target.value })}
          />
          <TextField
            fullWidth label="Nome" margin="normal"
            value={form.nome}
            onChange={(e) => setForm({ ...form, nome: e.target.value })}
          />
          <TextField
            fullWidth label="Descrição" margin="normal" multiline rows={3}
            value={form.descricao}
            onChange={(e) => setForm({ ...form, descricao: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAbrirModal(false)}>Cancelar</Button>
          <Button variant="contained" onClick={salvarCategoria}>Salvar</Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default Categorias
