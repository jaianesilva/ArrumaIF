import React, { useState } from 'react'
import { Box, Typography, Chip, Button, Dialog, DialogTitle, DialogContent, DialogActions, Grid } from '@mui/material'
import { chamados as dadosChamados, locais, categorias, usuarios } from '../data/database.js'

function Andamento() {

  const [chamados, setChamados] = useState(dadosChamados)
  const [detalheAberto, setDetalheAberto] = useState(null)

  function getNome(lista, id) {
    const item = lista.find(i => i.id === id)
    return item ? item.nome : '—'
  }

  // Move o chamado para o próximo status da coluna
  function avancarStatus(id, novoStatus) {
    const atualizados = chamados.map(c =>
      c.id === id ? { ...c, status: novoStatus } : c
    )
    setChamados(atualizados)
  }

  const corPrioridade = { urgente: 'error', alta: 'warning', media: 'default', baixa: 'success' }

  const colunas = [
    { chave: 'aberto',       titulo: '📂 Aberto',       cor: '#1565c0', proximo: 'em_andamento' },
    { chave: 'em_andamento', titulo: '⚙️ Em Andamento', cor: '#e65100', proximo: 'resolvido'    },
    { chave: 'resolvido',    titulo: '✅ Resolvido',    cor: '#2e7d32', proximo: null            },
  ]

  return (
    <Box>
      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">🗂️ Andamento</Typography>
        <Typography color="text.secondary" mt={0.5}>
          Acompanhe os chamados organizados por status
        </Typography>
      </Box>

      <div className="kanban-grid">
        {colunas.map(coluna => {
          const itensDaColuna = chamados.filter(c => c.status === coluna.chave)

          return (
            <div className="kanban-coluna" key={coluna.chave}>

              <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
                <Typography fontSize={13} fontWeight="bold" color={coluna.cor}>{coluna.titulo}</Typography>
                <Chip label={itensDaColuna.length} size="small" />
              </Box>

              {itensDaColuna.length === 0 && (
                <Typography variant="caption" color="text.secondary" display="block" textAlign="center" py={3}>
                  Nenhum chamado aqui
                </Typography>
              )}

              {itensDaColuna.map(chamado => {
                const cat = categorias.find(c => c.id === chamado.categoria_id)
                return (
                  <div
                    key={chamado.id}
                    className={`kanban-card ${chamado.prioridade}`}
                    onClick={() => setDetalheAberto(chamado)}
                  >
                    <div className="kanban-card-titulo">{chamado.titulo}</div>
                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                      {cat ? `${cat.icone} ${cat.nome}` : ''} · {getNome(locais, chamado.local_id)}
                    </Typography>
                    <Chip label={chamado.prioridade} size="small" color={corPrioridade[chamado.prioridade]} />

                    {coluna.proximo && (
                      <Button
                        size="small"
                        fullWidth
                        variant="outlined"
                        sx={{ mt: 1, fontSize: 11 }}
                        onClick={(e) => {
                          e.stopPropagation()
                          avancarStatus(chamado.id, coluna.proximo)
                        }}
                      >
                        Avançar →
                      </Button>
                    )}
                  </div>
                )
              })}
            </div>
          )
        })}
      </div>

      {}
      <Dialog open={!!detalheAberto} onClose={() => setDetalheAberto(null)} maxWidth="xs" fullWidth>
        {detalheAberto && (
          <>
            <DialogTitle>{detalheAberto.titulo}</DialogTitle>
            <DialogContent>
              <Typography variant="body2" color="text.secondary" mb={2}>
                {detalheAberto.descricao}
              </Typography>
              <Grid container spacing={1}>
                {[
                  ['📍 Local', getNome(locais, detalheAberto.local_id)],
                  ['👤 Solicitante', getNome(usuarios, detalheAberto.usuario_id)],
                  ['🏷️ Status', detalheAberto.status],
                  ['⚡ Prioridade', detalheAberto.prioridade],
                ].map(([chave, valor]) => (
                  <Grid item xs={6} key={chave}>
                    <Box sx={{ background: '#f5f5f5', borderRadius: 1, p: 1.2 }}>
                      <Typography variant="caption" color="text.secondary">{chave}</Typography>
                      <Typography variant="body2" fontWeight="bold">{valor}</Typography>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDetalheAberto(null)}>Fechar</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  )
}

export default Andamento
