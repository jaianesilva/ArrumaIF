import React, { useState } from 'react'
import {
  Box, Paper, Typography, TextField, Button, Alert
} from '@mui/material'
import logo from '../assets/arrumaif-logo.png'
import { usuarios } from '../data/database.js'

function Login({ onLogin }) {
  const [prontuario, setProntuario] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')

  function entrar() {
    const usuarioEncontrado = usuarios.find(
      usuario =>
        usuario.prontuario.toUpperCase() === prontuario.toUpperCase() &&
        usuario.senha === senha
    )

    if (usuarioEncontrado) {
      setErro('')
      onLogin(usuarioEncontrado)
    } else {
      setErro('Prontuário ou senha inválidos!')
    }
  }

  return (
    <Box className="tela-login">
      <Paper elevation={3} sx={{ p: 4, width: 360, borderRadius: 3 }}>

        <Box display="flex" justifyContent="center" mb={3}>
          <img src={logo} alt="ArrumaIF" style={{ width: '70%', height: 'auto' }} />
        </Box>

        <Typography variant="h6" fontWeight="bold" textAlign="center" mb={1}>
          Bem-vindo de volta!
        </Typography>

        <Typography variant="body2" color="text.secondary" textAlign="center" mb={3}>
          Entre com seu prontuário para continuar
        </Typography>

        {erro && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {erro}
          </Alert>
        )}

        <TextField
          fullWidth
          label="Prontuário"
          placeholder="Ex:BP303030"
          margin="normal"
          value={prontuario}
          onChange={(e) => setProntuario(e.target.value)}
        />

        <TextField
          fullWidth
          label="Senha"
          type="password"
          margin="normal"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
        />

        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 3, py: 1.2 }}
          onClick={entrar}
        >
          Entrar
        </Button>

        <Typography variant="caption" color="text.secondary" display="block" textAlign="center" mt={2}>
          Use: BP303030 / 123456
        </Typography>

      </Paper>
    </Box>
  )
}

export default Login
