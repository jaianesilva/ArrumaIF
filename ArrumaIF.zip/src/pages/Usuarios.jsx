import React, { useState } from 'react'
import {
  Box, Typography, Button, TextField, Card, Table, TableHead,
  TableBody, TableRow, TableCell, Chip, IconButton,
  Dialog, DialogTitle, DialogContent, DialogActions,
  FormControl, InputLabel, Select, MenuItem, Grid
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'

import { usuarios as dadosUsuarios, chamados } from '../data/database.js'

function Usuarios() {

  const [usuarios, setUsuarios] = useState(dadosUsuarios)
  const [busca, setBusca] = useState('')
  const [abrirModal, setAbrirModal] = useState(false)
  const [editandoId, setEditandoId] = useState(null)
  const [form, setForm] = useState({ nome: '', prontuario: '', tipo: 'aluno', turma: '' })

  const lista = usuarios.filter(usuario =>
    usuario.nome.toLowerCase().includes(busca.toLowerCase())
  )

  function chamadosDoUsuario(id) {
    return chamados.filter(chamado => chamado.usuario_id === id).length
  }

  function abrirNovo() {
    setForm({ nome: '', prontuario: '', tipo: 'aluno', turma: '' })
    setEditandoId(null)
    setAbrirModal(true)
  }

  function abrirEdicao(usuario) {
    setForm({
      nome: usuario.nome,
      prontuario: usuario.prontuario,
      tipo: usuario.tipo,
      turma: usuario.turma || ''
    })
    setEditandoId(usuario.id)
    setAbrirModal(true)
  }

  function salvar() {
    if (form.nome === '' || form.prontuario === '') {
      alert('Preencha nome e prontuário!')
      return
    }

    if (editandoId) {
      const atualizados = usuarios.map(u =>
        u.id === editandoId ? { ...u, ...form } : u
      )
      setUsuarios(atualizados)
    } else {
      const novo = { id: usuarios.length + 1, senha: '123456', ...form }
      setUsuarios([...usuarios, novo])
    }

    setAbrirModal(false)
  }

  function excluir(id) {
    setUsuarios(usuarios.filter(usuario => usuario.id !== id))
  }

  const corTipo = { aluno: 'success', professor: 'primary', servidor: 'default' }

  return (
    <Box>

      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">👥 Usuários</Typography>
        <Typography color="text.secondary">
          Alunos, professores e servidores
        </Typography>
      </Box>

      <Box display="flex" gap={2} mb={2}>
        <TextField
          size="small"
          label="Buscar"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <Button variant="contained" startIcon={<AddIcon />} onClick={abrirNovo}>
          Novo Usuário
        </Button>
      </Box>

      <Card>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Nome</TableCell>
              <TableCell>Prontuário</TableCell>
              <TableCell>Tipo</TableCell>
              <TableCell>Turma</TableCell>
              <TableCell>Chamados</TableCell>
              <TableCell>Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {lista.map(usuario => (
              <TableRow key={usuario.id}>
                <TableCell>{usuario.id}</TableCell>
                <TableCell>{usuario.nome}</TableCell>
                <TableCell>{usuario.prontuario}</TableCell>
                <TableCell>
                  <Chip label={usuario.tipo} size="small" color={corTipo[usuario.tipo]} />
                </TableCell>
                <TableCell>{usuario.turma || '—'}</TableCell>
                <TableCell>{chamadosDoUsuario(usuario.id)}</TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => abrirEdicao(usuario)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => excluir(usuario.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={abrirModal} onClose={() => setAbrirModal(false)}>
        <DialogTitle>{editandoId ? 'Editar Usuário' : 'Novo Usuário'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} mt={1}>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Nome"
                value={form.nome}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Prontuário"
                placeholder="Ex: BP3030288"
                value={form.prontuario}
                onChange={(e) => setForm({ ...form, prontuario: e.target.value })}
              />
            </Grid>

            <Grid item xs={6}>
              <FormControl fullWidth>
                <InputLabel>Tipo</InputLabel>
                <Select
                  value={form.tipo}
                  label="Tipo"
                  onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                >
                  <MenuItem value="aluno">Aluno</MenuItem>
                  <MenuItem value="professor">Professor</MenuItem>
                  <MenuItem value="servidor">Servidor</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Turma"
                value={form.turma}
                onChange={(e) => setForm({ ...form, turma: e.target.value })}
              />
            </Grid>

          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAbrirModal(false)}>Cancelar</Button>
          <Button variant="contained" onClick={salvar}>Salvar</Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default Usuarios
