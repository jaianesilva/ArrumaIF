import React, { useState } from 'react'
import {
  Box, Typography, Button, TextField, Card, Table, TableHead,
  TableBody, TableRow, TableCell, Chip, IconButton,
  Dialog, DialogTitle, DialogContent, DialogActions, Grid
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'

import { locais as dadosLocais, chamados } from '../data/database.js'

function Locais() {

  const [locais, setLocais] = useState(dadosLocais)
  const [busca, setBusca] = useState('')
  const [abrirModal, setAbrirModal] = useState(false)
  const [editandoId, setEditandoId] = useState(null)
  const [form, setForm] = useState({ nome: '', bloco: '', andar: '' })

  const lista = locais.filter(local =>
    local.nome.toLowerCase().includes(busca.toLowerCase())
  )

  function getChamadosDoLocal(id) {
    return chamados.filter(c => c.local_id === id).length
  }

  function abrirNovo() {
    setForm({ nome: '', bloco: '', andar: '' })
    setEditandoId(null)
    setAbrirModal(true)
  }

  function abrirEdicao(local) {
    setForm({ nome: local.nome, bloco: local.bloco, andar: local.andar })
    setEditandoId(local.id)
    setAbrirModal(true)
  }

  function salvar() {
    if (form.nome === '' || form.bloco === '') {
      alert('Preencha nome e bloco!')
      return
    }

    if (editandoId) {
      const atualizados = locais.map(l =>
        l.id === editandoId ? { ...l, ...form } : l
      )
      setLocais(atualizados)
    } else {
      const novo = { id: locais.length + 1, ...form }
      setLocais([...locais, novo])
    }

    setAbrirModal(false)
  }

  function excluir(id) {
    setLocais(locais.filter(local => local.id !== id))
  }

  return (
    <Box>
      <Typography variant="h5" fontWeight="bold" mb={1}>📍 Locais</Typography>
      <Typography color="text.secondary" mb={3}>
        Salas, laboratórios e áreas do campus
      </Typography>

      <Box display="flex" gap={2} mb={2}>
        <TextField
          size="small"
          label="Buscar"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <Button variant="contained" startIcon={<AddIcon />} onClick={abrirNovo}>
          Novo Local
        </Button>
      </Box>

      <Card>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Nome</TableCell>
              <TableCell>Bloco</TableCell>
              <TableCell>Andar</TableCell>
              <TableCell>Chamados</TableCell>
              <TableCell>Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {lista.map(local => (
              <TableRow key={local.id}>
                <TableCell>{local.id}</TableCell>
                <TableCell>{local.nome}</TableCell>
                <TableCell>
                  <Chip label={`Bloco ${local.bloco}`} size="small" color="success" variant="outlined" />
                </TableCell>
                <TableCell>{local.andar}</TableCell>
                <TableCell>
                  <Chip label={getChamadosDoLocal(local.id)} size="small" />
                </TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => abrirEdicao(local)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => excluir(local.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={abrirModal} onClose={() => setAbrirModal(false)}>
        <DialogTitle>{editandoId ? 'Editar Local' : 'Novo Local'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} mt={1}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Nome"
                value={form.nome}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Bloco"
                value={form.bloco}
                onChange={(e) => setForm({ ...form, bloco: e.target.value })}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Andar"
                value={form.andar}
                onChange={(e) => setForm({ ...form, andar: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAbrirModal(false)}>Cancelar</Button>
          <Button variant="contained" onClick={salvar}>Salvar</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Locais
